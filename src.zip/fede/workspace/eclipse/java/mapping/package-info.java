

@PackageInfo(version="1.0.0", requirePackages={})
package fede.workspace.eclipse.java.mapping;

import fr.imag.adele.packageinfo.PackageInfo;
